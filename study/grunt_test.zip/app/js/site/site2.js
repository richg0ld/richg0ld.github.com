/**
 * site2.js
 */

(function(){
	// console.log('site2 js');
})();

